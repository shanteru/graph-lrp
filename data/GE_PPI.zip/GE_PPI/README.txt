Please download in this GE_PPI directory 3 csv files:

GEO_HG_PPI.csv
HPRD_PPI.csv
labels_GEO_HG.csv

new link: http://mypathsem.bioinf.med.uni-goettingen.de/resources/glrp

old link: https://owncloud.gwdg.de/index.php/s/l2zzOtscXAwS8de
